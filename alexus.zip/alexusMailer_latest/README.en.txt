FILES DESCRIPTION

alexusMailer_v2.0.php
Main sender file

FAQ.pdf
PDF version of russian documentation, english version is built in

Shell folder (REQUIRED FOR SENDING THROUGH WEB SHELLS!)
Contains modules wich allows alexusMailer send through web shells, 
they connect in aouto mode, you can add self written modules too. 
Warning! Modules for r57 and c99 can be detected as malware for "eval(base64_decode" code, 
if you have such error, just remove them from shells folder.